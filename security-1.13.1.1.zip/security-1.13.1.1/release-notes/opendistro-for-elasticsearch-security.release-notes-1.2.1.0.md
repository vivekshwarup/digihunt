## 2019-10-10, Version 1.2.1.0

- Support for Elasticsearch 7.2.1
