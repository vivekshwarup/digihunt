## 2020-05-18 Version 1.8.0.0

Supported Elasticsearch version 7.7.0

### Enhancements
- Added support for Elasticsearch 7.7.0 ([#361](https://github.com/opendistro-for-elasticsearch/security/pull/361), [#461](https://github.com/opendistro-for-elasticsearch/security/pull/461))
- Implemented migration and validation APIs for version upgrade ([#454](https://github.com/opendistro-for-elasticsearch/security/pull/454))

### Maintenance
- Jackson-databind version bump ([#406](https://github.com/opendistro-for-elasticsearch/security/pull/406))
