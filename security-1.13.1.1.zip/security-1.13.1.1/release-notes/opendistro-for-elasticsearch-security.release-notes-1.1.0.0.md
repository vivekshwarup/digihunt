## 2019-06-21, Version 1.1.0.0

- Support For Elasticsearch 7.1
