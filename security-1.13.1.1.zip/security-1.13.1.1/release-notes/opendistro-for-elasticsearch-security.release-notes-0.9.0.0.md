## 2019-04-23 Version 0.9.0.0

- Support For Elasticsearch 6.7
- Handle attributes when impersonating user
