## 2020-03-12 Version 1.6.0.0

- Support for Elasticsearch 7.6.1
