## 2019-03-19 Version 0.7.0.1
 
- Fixed git repo URLs in pom.xml
- Handle overridden Transport channels.
- Fixed "opendistro_security.advanced_modules_enabled" configuration parameter
- Fixed sample configuration and UTs
