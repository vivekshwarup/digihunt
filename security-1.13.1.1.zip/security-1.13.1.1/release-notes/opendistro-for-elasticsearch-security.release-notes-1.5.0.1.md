## 2020-03-05 Version 1.5.0.1

- Adding capability to hot reload ssl certificates
- Added changes for SuperAdmin to update/add/delete reserved configs
