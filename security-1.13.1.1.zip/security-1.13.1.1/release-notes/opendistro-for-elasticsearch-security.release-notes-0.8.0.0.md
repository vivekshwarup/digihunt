## 2019-04-04 Version 0.8.0.0

- Support For  Elasticsearch 6.6
