## 2020-01-24 Version 1.4.0.0

- Support for Elasticsearch 7.4.2
- Removing support of OpenSSL for Java 12+
- Merging all security repos (security-parent and security-advanced-modules into security)
- New API to fetch and update account details (currently used for password update)
- Fix bug in demo install script to correctly configure when deb/rpm installs are present
