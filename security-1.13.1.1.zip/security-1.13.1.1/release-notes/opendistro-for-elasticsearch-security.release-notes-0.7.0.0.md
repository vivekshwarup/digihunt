## 2019-03-12 Version 0.7.0.0

- Initial launch of security for opendistro-for-elasticsearch
