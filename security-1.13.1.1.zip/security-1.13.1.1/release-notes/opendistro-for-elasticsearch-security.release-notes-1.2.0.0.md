## 2019-08-07, Version 1.2.0.0

- Support for Elasticsearch 7.2.0
